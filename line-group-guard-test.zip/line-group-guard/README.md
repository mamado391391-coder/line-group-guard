# LINE Group Guard

نسخة اختبار لمراقبة أحداث دخول الأعضاء وإرسال تنبيه داخل الجروب باستخدام LINE Messaging API الرسمية.

## الأوامر
- `.help` — عرض المساعدة
- `.lurk on` — تشغيل تنبيهات دخول الأعضاء
- `.lurk off` — إيقاف التنبيهات

## النشر على Render
1. أنشئ Web Service من هذا المستودع.
2. Build Command: `pip install -r requirements.txt`
3. Start Command: `gunicorn bot:app`
4. أضف متغيري البيئة:
   - `LINE_CHANNEL_SECRET`
   - `LINE_CHANNEL_ACCESS_TOKEN`
5. بعد النشر، اجعل Webhook URL هو: `https://YOUR-SERVICE.onrender.com/webhook`
6. فعّل Use webhook من إعدادات Messaging API، ثم اختبر Verify.

## حدود مهمة
LINE Messaging API الرسمية لا توفر طرد أعضاء الجروب أو إدارة مسؤولي الجروب.
هذا المشروع يرسل تنبيهات عند وصول حدث `memberJoined` فقط، ولا يضمن معرفة الشخص الذي دعا العضو.
لا تضع Channel Secret أو Access Token داخل ملفات المستودع أو تشاركهما في المحادثات.
